#!/usr/bin/env bash
# snush 자동 테스트 스크립트 (빌드 + 기능 점검 + 로그 저장)
# Log: test_log.txt

set -u  # (일부 테스트가 실패 코드를 내도 계속 진행해야 하므로 -e는 사용하지 않음)
LOG="test_log.txt"
ROOT="$HOME/201912551_assign4"
SRC="$ROOT/src"

echo "[INFO] start: $(date)" > "$LOG"

# 0) 빌드
{
  echo "===== BUILD ====="
  cd "$SRC" || exit 1
  make clean >/dev/null 2>&1 || true
  make CC=gcc800 all
  echo
} |& tee -a "$LOG"

# 환경 정리 (토큰 덤프 끄기)
unset DEBUG

# 헬퍼: 한 블록을 snush에 입력하고 결과 기록
run_block () {
  local title="$1"
  local payload="$2"

  echo "===== $title =====" | tee -a "$LOG"
  echo "$payload" | sed 's/^/>>> /' | tee -a "$LOG"

  # 구분선
  {
    echo
    echo "--- snush output ---"
  } >> "$LOG"

  # 실제 실행
  "$SRC/snush" <<SNUSH |& tee -a "$LOG"
$payload
SNUSH

  echo -e "--- end ($title) ---\n" | tee -a "$LOG"
}

########## 테스트 시작 ##########

# 1) 기본/내장
run_block "BUILTINS" \
'pwd
cd
cd /tmp
pwd
exit'

# 2) 리다이렉션
run_block "REDIRECTION" \
'echo hello > f.txt
cat < f.txt
echo x > a > b
cat <'

# 3) 파이프
run_block "PIPES" \
'ls | sort
cat /etc/passwd | grep bash | wc -l
cat /etc/passwd | head -n 3'

# 4) execvp 실패 (다른 잡에 영향 없어야 함)
run_block "EXECVP_FAILURE" \
'nosuchcmd
echo AFTER-FAILURE'

# 5) 백그라운드 잡 (시작 안내/완료 정리 확인)
run_block "BACKGROUND_JOBS_START" \
'tools/myspin 1 &
tools/myprod 5 | sort -rn &'

# BG 종료가 처리되도록 잠시 대기 후, 빈 커맨드로 check_bg_status() 출력 유도
sleep 2
run_block "BACKGROUND_JOBS_FLUSH" \
''

# 6) 파이프 + 백그라운드
run_block "PIPE_AND_BG" \
'cat /etc/passwd | wc -l &
echo BG-PIPE-STARTED'

# 7) MAX_JOBS 스트레스(선택적): 18개 요청 → 16개 이후는 거절되는지 메시지 확인
run_block "MAX_JOBS_STRESS (optional)" \
'tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &
tools/myspin 3 &'

# BG 처리 시간 확보 후 flush
sleep 4
run_block "FINAL_FLUSH" \
'exit'

echo "[INFO] done: $(date)" >> "$LOG"

echo
echo "=== 테스트 완료 ==="
echo "로그 파일: $LOG"
